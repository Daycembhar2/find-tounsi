import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Package, Plus, Eye, Pencil } from "lucide-react"

export default async function VendeurProduitsPage() {
  const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000"

  const sellerId = "fea19d27-0d28-463c-bd5a-51884ee58686"

  const res = await fetch(
    `${API_URL}/api/products?seller_id=${sellerId}`,
    { cache: "no-store" }
  )

  const json = await res.json()
  const products = json.data || []

  return (
    <div className="container py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">
          Mes Produits
        </h1>

        <Button asChild>
          <Link href="/vendeur/produits/ajouter">
            <Plus className="w-4 h-4 mr-2" />
            Ajouter
          </Link>
        </Button>
      </div>

      {products.length === 0 ? (
        <div className="text-center py-16">
          <Package className="w-12 h-12 mx-auto mb-4 opacity-30" />
          <p>Aucun produit.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {products.map((product: any) => (
            <div
              key={product.id}
              className="border rounded-xl p-4 flex items-center gap-4"
            >
              <img
                src={product.image_url || "/placeholder.svg"}
                alt={product.name}
                className="w-20 h-20 rounded-lg object-cover"
              />

              <div className="flex-1">
                <h2 className="font-semibold">
                  {product.name}
                </h2>

                <p className="text-sm text-muted-foreground">
                  {product.category?.name}
                </p>

                <p className="font-bold text-primary">
                  {Number(product.price || 0).toFixed(3)} TND
                </p>

                {product.is_100_percent_tunisian && (
                  <Badge variant="outline">
                    🇹🇳 100% Tunisien
                  </Badge>
                )}
              </div>

              <div className="flex gap-2">
                <Button variant="outline" asChild>
                  <Link href={`/produits/${product.id}`}>
                    <Eye className="w-4 h-4" />
                  </Link>
                </Button>

                <Button asChild>
                  <Link href={`/vendeur/produits/${product.id}/modifier`}>
                    <Pencil className="w-4 h-4" />
                  </Link>
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}