"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { useRouter, useParams } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Upload, X, CheckCircle2, AlertCircle, ImagePlus, Barcode, MapPin, Tag, Package, Trash2 } from "lucide-react"
import type { Category, Region, Product } from "@/lib/types"

const UNITS = [
  { value: "g",   label: "Grammes (g)" },
  { value: "kg",  label: "Kilogrammes (kg)" },
  { value: "ml",  label: "Millilitres (ml)" },
  { value: "l",   label: "Litres (l)" },
  { value: "pcs", label: "Pièces (pcs)" },
  { value: "m",   label: "Mètres (m)" },
  { value: "m2",  label: "Mètres² (m²)" },
]

export default function ModifierProduitPage() {
  const router = useRouter()
  const params = useParams()
  const supabase = createClient()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const productId = params.id as string

  const [sellerId, setSellerId]           = useState<string | null>(null)
  const [isLoading, setIsLoading]         = useState(true)
  const [isSaving, setIsSaving]           = useState(false)
  const [error, setError]                 = useState<string | null>(null)
  const [success, setSuccess]             = useState(false)

  // Champs
  const [name, setName]                   = useState("")
  const [nameAr, setNameAr]               = useState("")
  const [description, setDescription]     = useState("")
  const [descriptionAr, setDescriptionAr] = useState("")
  const [price, setPrice]                 = useState("")
  const [stock, setStock]                 = useState("")
  const [barcode, setBarcode]             = useState("")
  const [categoryId, setCategoryId]       = useState("")
  const [regionId, setRegionId]           = useState("")
  const [quantityValue, setQuantityValue] = useState("")
  const [quantityUnit, setQuantityUnit]   = useState("g")
  const [ingredients, setIngredients]     = useState("")
  const [isTunisian, setIsTunisian]       = useState(true)
  const [isAvailable, setIsAvailable]     = useState(true)

  // Images existantes (URLs) + nouvelles (Files)
  const [existingImages, setExistingImages] = useState<string[]>([])
  const [removedImages, setRemovedImages]   = useState<string[]>([])
  const [newImages, setNewImages]           = useState<File[]>([])
  const [newPreviews, setNewPreviews]       = useState<string[]>([])

  const [categories, setCategories] = useState<Category[]>([])
  const [regions, setRegions]       = useState<Region[]>([])

  useEffect(() => { init() }, [productId])

  const init = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push("/auth/login"); return }

      const { data: seller } = await supabase
        .from("sellers").select("id").eq("user_id", user.id).single()
      if (!seller) { router.push("/vendeur/inscription"); return }
      setSellerId(seller.id)

      // Charger produit + listes
      const [productRes, catRes, regRes] = await Promise.all([
        supabase.from("products").select("*").eq("id", productId).eq("seller_id", seller.id).single(),
        supabase.from("categories").select("id, name, slug").order("name"),
        supabase.from("regions").select("id, name").order("name"),
      ])

      if (productRes.error || !productRes.data) {
        setError("Produit introuvable ou accès non autorisé")
        setIsLoading(false)
        return
      }

      const p = productRes.data as any
      setName(p.name || "")
      setNameAr(p.name_ar || "")
      setDescription(p.description || "")
      setDescriptionAr(p.description_ar || "")
      setPrice(p.price?.toString() || "")
      setStock(p.stock?.toString() || "")
      setBarcode(p.barcode || "")
      setCategoryId(p.category_id || "")
      setRegionId(p.region_id || "")
      setQuantityValue(p.quantity_value?.toString() || "")
      setQuantityUnit(p.quantity_unit || "g")
      setIngredients(p.ingredients || "")
      setIsTunisian(p.is_100_percent_tunisian ?? true)
      setIsAvailable(p.is_available ?? true)

      // Images existantes
      const imgs: string[] = []
      if (p.images && Array.isArray(p.images)) imgs.push(...p.images)
      else if (p.image_url) imgs.push(p.image_url)
      setExistingImages(imgs)

      if (catRes.data) setCategories(catRes.data as any)
      if (regRes.data) setRegions(regRes.data as any)
    } catch (err) {
      setError("Erreur de chargement")
    } finally {
      setIsLoading(false)
    }
  }

  const removeExistingImage = (url: string) => {
    setExistingImages((prev) => prev.filter((u) => u !== url))
    setRemovedImages((prev) => [...prev, url])
  }

  const handleNewImages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    const total = existingImages.length + newImages.length + files.length
    if (total > 5) { setError("Maximum 5 images autorisées"); return }
    setNewImages((prev) => [...prev, ...files])
    setNewPreviews((prev) => [...prev, ...files.map((f) => URL.createObjectURL(f))])
  }

  const removeNewImage = (index: number) => {
    URL.revokeObjectURL(newPreviews[index])
    setNewImages((prev) => prev.filter((_, i) => i !== index))
    setNewPreviews((prev) => prev.filter((_, i) => i !== index))
  }

  const uploadNewImages = async (userId: string): Promise<string[]> => {
    const urls: string[] = []
    for (const image of newImages) {
      const fileName = `${userId}/${Date.now()}-${image.name.replace(/\s/g, "_")}`
      const { error: uploadError } = await supabase.storage.from("product-images").upload(fileName, image)
      if (!uploadError) {
        const { data: pub } = supabase.storage.from("product-images").getPublicUrl(fileName)
        if (pub?.publicUrl) urls.push(pub.publicUrl)
      }
    }
    return urls
  }

  const validate = (): boolean => {
    setError(null)
    if (!name.trim())        { setError("Le nom est obligatoire"); return false }
    if (!description.trim()) { setError("La description est obligatoire"); return false }
    if (!price || isNaN(Number(price)) || Number(price) <= 0) {
      setError("Veuillez entrer un prix valide"); return false
    }
    if (!categoryId) { setError("Veuillez choisir une catégorie"); return false }
    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validate() || !sellerId) return

    try {
      setIsSaving(true)
      setError(null)

      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Non authentifié")

      const uploadedUrls = await uploadNewImages(user.id)
      const allImages = [...existingImages, ...uploadedUrls]
      const mainImage = allImages[0] || null

      const { error: updateError } = await supabase
        .from("products")
        .update({
          name:                    name.trim(),
          name_ar:                 nameAr.trim() || null,
          description:             description.trim(),
          description_ar:          descriptionAr.trim() || null,
          price:                   Number(price),
          stock:                   stock ? Number(stock) : null,
          barcode:                 barcode.trim() || null,
          category_id:             categoryId || null,
          region_id:               regionId || null,
          image_url:               mainImage,
          images:                  allImages.length > 0 ? allImages : null,
          quantity_value:          quantityValue ? Number(quantityValue) : null,
          quantity_unit:           quantityValue ? quantityUnit : null,
          ingredients:             ingredients.trim() || null,
          is_100_percent_tunisian: isTunisian,
          is_available:            isAvailable,
          updated_at:              new Date().toISOString(),
        })
        .eq("id", productId)
        .eq("seller_id", sellerId)

      if (updateError) throw new Error(updateError.message)

      setSuccess(true)
      setTimeout(() => router.push("/vendeur/produits"), 1500)
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erreur lors de la mise à jour")
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary" />
      </div>
    )
  }

  if (error && !name) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-4 p-4">
        <AlertCircle className="w-12 h-12 text-destructive" />
        <p className="text-lg font-semibold">{error}</p>
        <Button asChild><Link href="/vendeur/produits">Retour aux produits</Link></Button>
      </div>
    )
  }

  const totalImages = existingImages.length + newImages.length

  return (
    <div className="min-h-screen bg-muted/30 pb-10">

      {/* Header */}
      <div className="bg-background border-b sticky top-0 z-30">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center gap-3">
          <Button variant="ghost" size="icon" className="h-8 w-8" asChild>
            <Link href="/vendeur/produits"><ArrowLeft className="w-4 h-4" /></Link>
          </Button>
          <div className="flex-1 min-w-0">
            <h1 className="font-semibold text-base leading-none truncate">Modifier : {name}</h1>
            <p className="text-xs text-muted-foreground">Mettez à jour les informations</p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="max-w-3xl mx-auto px-4 py-6 space-y-5">

        {/* ─── Images ─── */}
        <Card className="border-none shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <ImagePlus className="w-4 h-4 text-primary" /> Photos du produit
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3 flex-wrap">
              {/* Images existantes */}
              {existingImages.map((url, i) => (
                <div key={url} className="relative w-20 h-20 rounded-lg overflow-hidden border bg-muted group">
                  <img src={url} alt="" className="w-full h-full object-cover"
                    onError={(e) => { (e.target as HTMLImageElement).src = "/placeholder.svg" }} />
                  {i === 0 && (
                    <span className="absolute bottom-0 left-0 right-0 bg-primary/80 text-white text-[9px] text-center py-0.5">
                      Principale
                    </span>
                  )}
                  <button type="button" onClick={() => removeExistingImage(url)}
                    className="absolute top-1 right-1 w-5 h-5 bg-black/60 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <X className="w-3 h-3 text-white" />
                  </button>
                </div>
              ))}

              {/* Nouvelles images */}
              {newPreviews.map((src, i) => (
                <div key={i} className="relative w-20 h-20 rounded-lg overflow-hidden border-2 border-primary/40 bg-muted group">
                  <img src={src} alt="" className="w-full h-full object-cover" />
                  <span className="absolute bottom-0 left-0 right-0 bg-primary/80 text-white text-[9px] text-center py-0.5">
                    Nouvelle
                  </span>
                  <button type="button" onClick={() => removeNewImage(i)}
                    className="absolute top-1 right-1 w-5 h-5 bg-black/60 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <X className="w-3 h-3 text-white" />
                  </button>
                </div>
              ))}

              {totalImages < 5 && (
                <button type="button" onClick={() => fileInputRef.current?.click()}
                  className="w-20 h-20 rounded-lg border-2 border-dashed border-muted-foreground/30 flex flex-col items-center justify-center gap-1 hover:border-primary hover:bg-primary/5 transition-colors text-muted-foreground hover:text-primary">
                  <Upload className="w-5 h-5" />
                  <span className="text-[10px]">Ajouter</span>
                </button>
              )}
              <input ref={fileInputRef} type="file" accept="image/*" multiple
                className="hidden" onChange={handleNewImages} />
            </div>
          </CardContent>
        </Card>

        {/* ─── Infos de base ─── */}
        <Card className="border-none shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Package className="w-4 h-4 text-primary" /> Informations de base
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="grid gap-1.5">
                <Label htmlFor="name">Nom (FR) *</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="nameAr">Nom (AR)</Label>
                <Input id="nameAr" dir="rtl" value={nameAr} onChange={(e) => setNameAr(e.target.value)} />
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="description">Description (FR) *</Label>
              <Textarea id="description" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="descriptionAr">Description (AR)</Label>
              <Textarea id="descriptionAr" rows={2} dir="rtl" value={descriptionAr} onChange={(e) => setDescriptionAr(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="ingredients">Ingrédients / Composition</Label>
              <Textarea id="ingredients" rows={2} value={ingredients} onChange={(e) => setIngredients(e.target.value)} />
            </div>
          </CardContent>
        </Card>

        {/* ─── Prix & Stock ─── */}
        <Card className="border-none shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Prix & Stock</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-1.5">
                <Label htmlFor="price">Prix (TND) *</Label>
                <div className="relative">
                  <Input id="price" type="number" step="0.001" min="0"
                    value={price} onChange={(e) => setPrice(e.target.value)} className="pr-14" />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">TND</span>
                </div>
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="stock">Stock</Label>
                <Input id="stock" type="number" min="0" value={stock} onChange={(e) => setStock(e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-1.5">
                <Label htmlFor="quantityValue">Quantité / Contenance</Label>
                <Input id="quantityValue" type="number" step="0.1" value={quantityValue}
                  onChange={(e) => setQuantityValue(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label>Unité</Label>
                <Select value={quantityUnit} onValueChange={setQuantityUnit}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {UNITS.map((u) => <SelectItem key={u.value} value={u.value}>{u.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* ─── Classification ─── */}
        <Card className="border-none shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Tag className="w-4 h-4 text-primary" /> Classification
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="grid gap-1.5">
                <Label>Catégorie *</Label>
                <Select value={categoryId} onValueChange={setCategoryId}>
                  <SelectTrigger><SelectValue placeholder="Choisir" /></SelectTrigger>
                  <SelectContent>
                    {categories.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label className="flex items-center gap-1"><MapPin className="w-3 h-3" /> Région</Label>
                <Select value={regionId} onValueChange={setRegionId}>
                  <SelectTrigger><SelectValue placeholder="Choisir" /></SelectTrigger>
                  <SelectContent>
                    {regions.map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="barcode" className="flex items-center gap-1">
                <Barcode className="w-3 h-3" /> Code-barres
              </Label>
              <Input id="barcode" value={barcode} onChange={(e) => setBarcode(e.target.value)} />
            </div>
          </CardContent>
        </Card>

        {/* ─── Options ─── */}
        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/40">
              <div>
                <p className="text-sm font-medium">🇹🇳 Produit 100% Tunisien</p>
                <p className="text-xs text-muted-foreground">Fabriqué entièrement en Tunisie</p>
              </div>
              <Switch checked={isTunisian} onCheckedChange={setIsTunisian} />
            </div>
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/40">
              <div>
                <p className="text-sm font-medium flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600" /> Disponible à la vente
                </p>
                <p className="text-xs text-muted-foreground">Visible par les clients</p>
              </div>
              <Switch checked={isAvailable} onCheckedChange={setIsAvailable} />
            </div>
          </CardContent>
        </Card>

        {error && (
          <div className="flex items-start gap-2 p-4 rounded-lg bg-destructive/10 text-destructive text-sm">
            <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />{error}
          </div>
        )}
        {success && (
          <div className="flex items-center gap-2 p-4 rounded-lg bg-green-50 text-green-700 text-sm">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
            Produit mis à jour ! Redirection...
          </div>
        )}

        <div className="flex gap-3 pt-2">
          <Button type="button" variant="outline" className="flex-1" asChild>
            <Link href="/vendeur/produits">Annuler</Link>
          </Button>
          <Button type="submit" className="flex-1" disabled={isSaving || success}>
            {isSaving ? (
              <span className="flex items-center gap-2">
                <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                Enregistrement...
              </span>
            ) : "Enregistrer les modifications"}
          </Button>
        </div>

      </form>
    </div>
  )
}