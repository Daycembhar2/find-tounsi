"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  ArrowLeft, CheckCircle2, AlertCircle, Camera,
  Store, MapPin, Phone, Mail, Globe, CreditCard,
  Shield, LogOut, Star, Package, ShoppingBag,
} from "lucide-react"

const GOUVERNORATS = [
  "Ariana","Béja","Ben Arous","Bizerte","Gabès","Gafsa",
  "Jendouba","Kairouan","Kasserine","Kébili","Kef","Mahdia",
  "Manouba","Médenine","Monastir","Nabeul","Sfax","Sidi Bouzid",
  "Siliana","Sousse","Tataouine","Tozeur","Tunis","Zaghouan",
]

const BANKS = ["STB","BNA","BH Bank","Attijari","BIAT","UIB","Amen Bank","CIB","Zitouna","Autre"]

export default function VendeurProfilPage() {
  const router = useRouter()
  const supabase = createClient()
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [isLoading, setIsLoading]   = useState(true)
  const [isSaving, setIsSaving]     = useState(false)
  const [error, setError]           = useState<string | null>(null)
  const [success, setSuccess]       = useState<string | null>(null)
  const [activeTab, setActiveTab]   = useState<"info" | "banque" | "securite">("info")

  // Données vendeur
  const [sellerId, setSellerId]                   = useState<string | null>(null)
  const [businessName, setBusinessName]           = useState("")
  const [businessNameAr, setBusinessNameAr]       = useState("")
  const [businessDescription, setBusinessDescription] = useState("")
  const [phone, setPhone]                         = useState("")
  const [email, setEmail]                         = useState("")
  const [website, setWebsite]                     = useState("")
  const [address, setAddress]                     = useState("")
  const [city, setCity]                           = useState("")
  const [region, setRegion]                       = useState("")
  const [taxId, setTaxId]                         = useState("")
  const [bankName, setBankName]                   = useState("")
  const [bankAccount, setBankAccount]             = useState("")
  const [logoUrl, setLogoUrl]                     = useState<string | null>(null)
  const [logoFile, setLogoFile]                   = useState<File | null>(null)
  const [logoPreview, setLogoPreview]             = useState<string | null>(null)
  const [isVerified, setIsVerified]               = useState(false)
  const [totalSales, setTotalSales]               = useState(0)
  const [avgRating, setAvgRating]                 = useState(0)
  const [totalProducts, setTotalProducts]         = useState(0)

  // Sécurité
  const [currentPassword, setCurrentPassword]     = useState("")
  const [newPassword, setNewPassword]             = useState("")
  const [confirmPassword, setConfirmPassword]     = useState("")

  useEffect(() => { loadProfile() }, [])

  const loadProfile = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push("/auth/login"); return }

      const { data: seller, error: sellerErr } = await supabase
        .from("sellers").select("*").eq("user_id", user.id).single()
      if (sellerErr || !seller) { router.push("/vendeur/inscription"); return }

      setSellerId(seller.id)
      setBusinessName(seller.business_name || "")
      setBusinessNameAr(seller.business_name_ar || "")
      setBusinessDescription(seller.business_description || "")
      setPhone(seller.phone || "")
      setEmail(seller.email || "")
      setWebsite(seller.website || "")
      setAddress(seller.address || "")
      setCity(seller.city || "")
      setRegion(seller.region || "")
      setTaxId(seller.tax_id || "")
      setBankName(seller.bank_name || "")
      setBankAccount(seller.bank_account || "")
      setLogoUrl(seller.business_logo_url || null)
      setIsVerified(seller.is_verified || false)
      setTotalSales(seller.total_sales || 0)
      setAvgRating(seller.average_rating || 0)

      // Total produits
      const { count } = await supabase
        .from("products").select("id", { count: "exact" }).eq("seller_id", seller.id)
      setTotalProducts(count || 0)
    } catch (err) {
      setError("Erreur de chargement du profil")
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setLogoFile(file)
    const reader = new FileReader()
    reader.onload = () => setLogoPreview(reader.result as string)
    reader.readAsDataURL(file)
  }

  const uploadLogo = async (userId: string): Promise<string | null> => {
    if (!logoFile) return logoUrl
    const fileName = `${userId}/logo-${Date.now()}.${logoFile.name.split(".").pop()}`
    const { error } = await supabase.storage.from("seller-logos").upload(fileName, logoFile, { upsert: true })
    if (error) return logoUrl
    const { data: pub } = supabase.storage.from("seller-logos").getPublicUrl(fileName)
    return pub?.publicUrl || logoUrl
  }

  const saveInfo = async () => {
    if (!businessName.trim()) { setError("Le nom de l'entreprise est obligatoire"); return }
    try {
      setIsSaving(true)
      setError(null)
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) throw new Error("Non authentifié")

      const newLogoUrl = await uploadLogo(user.id)

      const { error: updateErr } = await supabase.from("sellers").update({
        business_name:        businessName.trim(),
        business_name_ar:     businessNameAr.trim() || null,
        business_description: businessDescription.trim() || null,
        phone:                phone.trim(),
        email:                email.trim(),
        website:              website.trim() || null,
        address:              address.trim(),
        city:                 city.trim(),
        region:               region || null,
        business_logo_url:    newLogoUrl,
        updated_at:           new Date().toISOString(),
      }).eq("id", sellerId!)

      if (updateErr) throw new Error(updateErr.message)
      if (newLogoUrl) setLogoUrl(newLogoUrl)
      setLogoFile(null)
      setLogoPreview(null)
      setSuccess("Profil mis à jour avec succès !")
      setTimeout(() => setSuccess(null), 3000)
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erreur de sauvegarde")
    } finally {
      setIsSaving(false)
    }
  }

  const saveBanque = async () => {
    try {
      setIsSaving(true)
      setError(null)
      const { error: updateErr } = await supabase.from("sellers").update({
        tax_id:       taxId.trim() || null,
        bank_name:    bankName || null,
        bank_account: bankAccount.trim() || null,
        updated_at:   new Date().toISOString(),
      }).eq("id", sellerId!)
      if (updateErr) throw new Error(updateErr.message)
      setSuccess("Informations bancaires mises à jour !")
      setTimeout(() => setSuccess(null), 3000)
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erreur de sauvegarde")
    } finally {
      setIsSaving(false)
    }
  }

  const savePassword = async () => {
    if (!newPassword || newPassword.length < 8) {
      setError("Le mot de passe doit contenir au moins 8 caractères"); return
    }
    if (newPassword !== confirmPassword) {
      setError("Les mots de passe ne correspondent pas"); return
    }
    try {
      setIsSaving(true)
      setError(null)
      const { error: passErr } = await supabase.auth.updateUser({ password: newPassword })
      if (passErr) throw new Error(passErr.message)
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")
      setSuccess("Mot de passe mis à jour !")
      setTimeout(() => setSuccess(null), 3000)
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Erreur de mise à jour")
    } finally {
      setIsSaving(false)
    }
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary" />
      </div>
    )
  }

  const currentLogo = logoPreview || logoUrl

  return (
    <div className="min-h-screen bg-muted/30 pb-10">

      {/* Header */}
      <div className="bg-background border-b sticky top-0 z-30">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="h-8 w-8" asChild>
              <Link href="/vendeur/dashboard"><ArrowLeft className="w-4 h-4" /></Link>
            </Button>
            <h1 className="font-semibold text-base">Mon Profil Vendeur</h1>
          </div>
          <Button variant="ghost" size="sm" onClick={handleLogout} className="text-muted-foreground">
            <LogOut className="w-4 h-4 mr-1" />
            <span className="hidden sm:inline">Déconnexion</span>
          </Button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6 space-y-5">

        {/* ─── Carte identité vendeur ─── */}
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5">
            <div className="flex items-center gap-4">
              {/* Logo */}
              <div className="relative flex-shrink-0">
                <div className="w-20 h-20 rounded-full bg-muted border-2 border-background shadow overflow-hidden flex items-center justify-center">
                  {currentLogo ? (
                    <img src={currentLogo} alt="Logo" className="w-full h-full object-cover" />
                  ) : (
                    <Store className="w-8 h-8 text-muted-foreground" />
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute bottom-0 right-0 w-7 h-7 bg-primary rounded-full flex items-center justify-center shadow-md hover:bg-primary/90 transition-colors"
                >
                  <Camera className="w-3.5 h-3.5 text-white" />
                </button>
                <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleLogoChange} />
              </div>

              {/* Infos */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="font-bold text-lg leading-none">{businessName}</h2>
                  {isVerified ? (
                    <Badge className="bg-green-100 text-green-700 border-green-200 gap-1 text-xs">
                      <CheckCircle2 className="w-3 h-3" /> Vérifié
                    </Badge>
                  ) : (
                    <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-xs">
                      En attente
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground mt-0.5">{city}{region ? `, ${region}` : ""}</p>
                <div className="flex items-center gap-4 mt-2">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Package className="w-3.5 h-3.5" /> {totalProducts} produits
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <ShoppingBag className="w-3.5 h-3.5" /> {totalSales} ventes
                  </div>
                  {avgRating > 0 && (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" /> {avgRating.toFixed(1)}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* ─── Onglets ─── */}
        <div className="flex gap-1 bg-muted p-1 rounded-lg">
          {([
            { id: "info",     label: "Informations",  icon: Store },
            { id: "banque",   label: "Banque",         icon: CreditCard },
            { id: "securite", label: "Sécurité",       icon: Shield },
          ] as const).map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => { setActiveTab(id); setError(null); setSuccess(null) }}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-md text-sm font-medium transition-all ${
                activeTab === id
                  ? "bg-background shadow text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{label}</span>
            </button>
          ))}
        </div>

        {/* ─── Messages globaux ─── */}
        {error && (
          <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
            <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />{error}
          </div>
        )}
        {success && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-green-50 text-green-700 text-sm">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" />{success}
          </div>
        )}

        {/* ─── Tab : Informations ─── */}
        {activeTab === "info" && (
          <Card className="border-none shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Informations de l'entreprise</CardTitle>
              <CardDescription className="text-xs">Ces informations sont visibles par les acheteurs</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="grid gap-1.5">
                  <Label htmlFor="businessName">Nom (FR) *</Label>
                  <Input id="businessName" value={businessName} onChange={(e) => setBusinessName(e.target.value)} />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="businessNameAr">Nom (AR)</Label>
                  <Input id="businessNameAr" dir="rtl" value={businessNameAr} onChange={(e) => setBusinessNameAr(e.target.value)} />
                </div>
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="businessDescription">Description</Label>
                <Textarea id="businessDescription" rows={3} value={businessDescription}
                  onChange={(e) => setBusinessDescription(e.target.value)} />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="grid gap-1.5">
                  <Label htmlFor="phone" className="flex items-center gap-1">
                    <Phone className="w-3 h-3" /> Téléphone
                  </Label>
                  <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="email" className="flex items-center gap-1">
                    <Mail className="w-3 h-3" /> Email
                  </Label>
                  <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="website" className="flex items-center gap-1">
                  <Globe className="w-3 h-3" /> Site web
                </Label>
                <Input id="website" placeholder="https://..." value={website} onChange={(e) => setWebsite(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="address" className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> Adresse
                </Label>
                <Input id="address" value={address} onChange={(e) => setAddress(e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-1.5">
                  <Label htmlFor="city">Ville</Label>
                  <Input id="city" value={city} onChange={(e) => setCity(e.target.value)} />
                </div>
                <div className="grid gap-1.5">
                  <Label>Gouvernorat</Label>
                  <Select value={region} onValueChange={setRegion}>
                    <SelectTrigger><SelectValue placeholder="Choisir" /></SelectTrigger>
                    <SelectContent>
                      {GOUVERNORATS.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button onClick={saveInfo} disabled={isSaving} className="w-full">
                {isSaving ? "Enregistrement..." : "Sauvegarder les informations"}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* ─── Tab : Banque ─── */}
        {activeTab === "banque" && (
          <Card className="border-none shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Informations bancaires & légales</CardTitle>
              <CardDescription className="text-xs">Utilisées pour les virements et la vérification</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-1.5">
                <Label htmlFor="taxId">Matricule fiscal</Label>
                <Input id="taxId" placeholder="Ex: 1234567/A/M/000" value={taxId}
                  onChange={(e) => setTaxId(e.target.value)} />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="grid gap-1.5">
                  <Label>Banque</Label>
                  <Select value={bankName} onValueChange={setBankName}>
                    <SelectTrigger><SelectValue placeholder="Choisir" /></SelectTrigger>
                    <SelectContent>
                      {BANKS.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-1.5">
                  <Label htmlFor="bankAccount">RIB</Label>
                  <Input id="bankAccount" placeholder="XX XXX XXXXXXXX XX" value={bankAccount}
                    onChange={(e) => setBankAccount(e.target.value)} />
                </div>
              </div>
              <div className="p-3 rounded-lg bg-blue-50 border border-blue-100 text-xs text-blue-700">
                🔒 Vos informations bancaires sont chiffrées et utilisées uniquement pour les virements de vos revenus.
              </div>
              <Button onClick={saveBanque} disabled={isSaving} className="w-full">
                {isSaving ? "Enregistrement..." : "Sauvegarder"}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* ─── Tab : Sécurité ─── */}
        {activeTab === "securite" && (
          <Card className="border-none shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Changer le mot de passe</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-1.5">
                <Label htmlFor="newPassword">Nouveau mot de passe</Label>
                <Input id="newPassword" type="password" placeholder="Min. 8 caractères"
                  value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="confirmPassword">Confirmer le mot de passe</Label>
                <Input id="confirmPassword" type="password" placeholder="Répéter"
                  value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
              </div>
              <Button onClick={savePassword} disabled={isSaving} className="w-full">
                {isSaving ? "Mise à jour..." : "Changer le mot de passe"}
              </Button>
            </CardContent>
          </Card>
        )}

      </div>
    </div>
  )
}