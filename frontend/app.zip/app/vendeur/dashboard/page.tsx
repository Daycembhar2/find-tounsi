"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Package, ShoppingBag, TrendingUp, Star, Plus, Eye,
  Settings, LogOut, Bell, CheckCircle2, Clock, XCircle,
  BarChart3, Users, ArrowUpRight, Store,
} from "lucide-react"
import type { Seller, Order, Product } from "@/lib/types"

interface DashboardStats {
  totalProducts: number
  totalOrders: number
  totalRevenue: number
  averageRating: number
  pendingOrders: number
  monthlyRevenue: number
}

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  pending:   { label: "En attente",  color: "bg-yellow-100 text-yellow-700 border-yellow-200", icon: <Clock className="w-3 h-3" /> },
  confirmed: { label: "Confirmée",   color: "bg-blue-100 text-blue-700 border-blue-200",       icon: <CheckCircle2 className="w-3 h-3" /> },
  shipped:   { label: "Expédiée",    color: "bg-purple-100 text-purple-700 border-purple-200", icon: <Package className="w-3 h-3" /> },
  delivered: { label: "Livrée",      color: "bg-green-100 text-green-700 border-green-200",    icon: <CheckCircle2 className="w-3 h-3" /> },
  cancelled: { label: "Annulée",     color: "bg-red-100 text-red-700 border-red-200",          icon: <XCircle className="w-3 h-3" /> },
}

export default function VendeurDashboard() {
  const router = useRouter()
  const supabase = createClient()

  const [seller, setSeller] = useState<Seller | null>(null)
  const [stats, setStats] = useState<DashboardStats>({
    totalProducts: 0, totalOrders: 0, totalRevenue: 0,
    averageRating: 0, pendingOrders: 0, monthlyRevenue: 0,
  })
  const [recentOrders, setRecentOrders] = useState<Order[]>([])
  const [recentProducts, setRecentProducts] = useState<Product[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    checkAuthAndLoad()
  }, [])

  const checkAuthAndLoad = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) {
        router.push("/auth/login?next=/vendeur/dashboard")
        return
      }

      // Charger le profil vendeur
      const { data: sellerData, error: sellerError } = await supabase
        .from("sellers")
        .select("*")
        .eq("user_id", user.id)
        .single()

      if (sellerError || !sellerData) {
        // Pas encore vendeur → rediriger vers inscription
        router.push("/vendeur/inscription")
        return
      }

      setSeller(sellerData)

      // Charger stats en parallèle
      await Promise.all([
        loadStats(sellerData.id),
        loadRecentOrders(sellerData.id),
        loadRecentProducts(sellerData.id),
      ])
    } catch (err) {
      console.error("Erreur dashboard:", err)
    } finally {
      setIsLoading(false)
    }
  }

  const loadStats = async (sellerId: string) => {
    const [productsRes, ordersRes] = await Promise.all([
      supabase.from("products").select("id", { count: "exact" }).eq("seller_id", sellerId),
      supabase.from("orders").select("total_amount, status, created_at").eq("seller_id", sellerId),
    ])

    const orders = ordersRes.data || []
    const now = new Date()
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)

    const totalRevenue = orders
      .filter((o) => o.status === "delivered")
      .reduce((sum, o) => sum + Number(o.total_amount), 0)

    const monthlyRevenue = orders
      .filter((o) => o.status === "delivered" && new Date(o.created_at) >= startOfMonth)
      .reduce((sum, o) => sum + Number(o.total_amount), 0)

    setStats({
      totalProducts: productsRes.count || 0,
      totalOrders: orders.length,
      totalRevenue,
      monthlyRevenue,
      pendingOrders: orders.filter((o) => o.status === "pending").length,
      averageRating: Number((sellerData as any)?.average_rating || 0),
    })
  }

  const loadRecentOrders = async (sellerId: string) => {
    const { data } = await supabase
      .from("orders")
      .select("*, order_items(*, product:products(name, image_url))")
      .eq("seller_id", sellerId)
      .order("created_at", { ascending: false })
      .limit(5)
    if (data) setRecentOrders(data as any)
  }

  const loadRecentProducts = async (sellerId: string) => {
    const { data } = await supabase
      .from("products")
      .select("*")
      .eq("seller_id", sellerId)
      .order("created_at", { ascending: false })
      .limit(4)
    if (data) setRecentProducts(data as any)
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  // ─── Loading ──────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center space-y-3">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto" />
          <p className="text-muted-foreground">Chargement du tableau de bord...</p>
        </div>
      </div>
    )
  }

  const sellerData = seller as any

  return (
    <div className="min-h-screen bg-muted/30">

      {/* ─── Sidebar desktop / Top bar mobile ─── */}
      <header className="bg-background border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              {sellerData?.business_logo_url ? (
                <img src={sellerData.business_logo_url} alt="" className="w-8 h-8 rounded-full object-cover" />
              ) : (
                <Store className="w-4 h-4 text-primary" />
              )}
            </div>
            <div className="hidden sm:block">
              <p className="font-semibold text-sm leading-none">{sellerData?.business_name || "Mon Espace"}</p>
              <p className="text-xs text-muted-foreground">Espace Vendeur</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-1">
            {[
              { href: "/vendeur/dashboard", label: "Tableau de bord", icon: BarChart3 },
              { href: "/vendeur/produits", label: "Produits", icon: Package },
              { href: "/vendeur/commandes", label: "Commandes", icon: ShoppingBag },
              { href: "/vendeur/profil", label: "Profil", icon: Settings },
            ].map(({ href, label, icon: Icon }) => (
              <Link key={href} href={href}
                className="flex items-center gap-2 px-3 py-1.5 rounded-md text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
                <Icon className="w-4 h-4" />
                {label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            {stats.pendingOrders > 0 && (
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="w-4 h-4" />
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 rounded-full text-white text-[10px] flex items-center justify-center">
                  {stats.pendingOrders}
                </span>
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={handleLogout} className="text-muted-foreground">
              <LogOut className="w-4 h-4 mr-1" />
              <span className="hidden sm:inline">Déconnexion</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">

        {/* ─── Welcome + badge vérification ─── */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold">
              Bonjour, {sellerData?.business_name} 👋
            </h1>
            <p className="text-muted-foreground text-sm">Voici un aperçu de votre activité</p>
          </div>
          <div className="flex items-center gap-2">
            {sellerData?.is_verified ? (
              <Badge className="bg-green-100 text-green-700 border border-green-200 gap-1">
                <CheckCircle2 className="w-3 h-3" /> Vendeur vérifié
              </Badge>
            ) : (
              <Badge className="bg-amber-100 text-amber-700 border border-amber-200 gap-1">
                <Clock className="w-3 h-3" /> Vérification en attente
              </Badge>
            )}
            <Button asChild size="sm">
              <Link href="/vendeur/produits/ajouter">
                <Plus className="w-4 h-4 mr-1" /> Ajouter un produit
              </Link>
            </Button>
          </div>
        </div>

        {/* ─── Stats cards ─── */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              title: "Produits",
              value: stats.totalProducts,
              icon: Package,
              color: "text-blue-600",
              bg: "bg-blue-50",
              sub: "en ligne",
            },
            {
              title: "Commandes",
              value: stats.totalOrders,
              icon: ShoppingBag,
              color: "text-purple-600",
              bg: "bg-purple-50",
              sub: `${stats.pendingOrders} en attente`,
            },
            {
              title: "Revenu total",
              value: `${stats.totalRevenue.toFixed(3)} TND`,
              icon: TrendingUp,
              color: "text-green-600",
              bg: "bg-green-50",
              sub: `${stats.monthlyRevenue.toFixed(3)} ce mois`,
            },
            {
              title: "Note moyenne",
              value: stats.averageRating > 0 ? stats.averageRating.toFixed(1) : "—",
              icon: Star,
              color: "text-yellow-600",
              bg: "bg-yellow-50",
              sub: "sur 5",
            },
          ].map((stat) => {
            const Icon = stat.icon
            return (
              <Card key={stat.title} className="border-none shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className={`w-9 h-9 rounded-lg ${stat.bg} flex items-center justify-center`}>
                      <Icon className={`w-5 h-5 ${stat.color}`} />
                    </div>
                    <ArrowUpRight className="w-4 h-4 text-muted-foreground/40" />
                  </div>
                  <p className="text-2xl font-bold leading-none mb-1">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.title} · {stat.sub}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* ─── Commandes récentes ─── */}
          <div className="lg:col-span-2">
            <Card className="border-none shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-3">
                <CardTitle className="text-base">Commandes récentes</CardTitle>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/vendeur/commandes" className="text-primary text-xs">
                    Voir tout <ArrowUpRight className="w-3 h-3 ml-1 inline" />
                  </Link>
                </Button>
              </CardHeader>
              <CardContent>
                {recentOrders.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <ShoppingBag className="w-10 h-10 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">Aucune commande pour l'instant</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {recentOrders.map((order: any) => {
                      const cfg = STATUS_CONFIG[order.status] || STATUS_CONFIG.pending
                      return (
                        <div key={order.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/40 hover:bg-muted/70 transition-colors">
                          <div className="min-w-0">
                            <p className="font-medium text-sm truncate">#{order.order_number}</p>
                            <p className="text-xs text-muted-foreground truncate">{order.delivery_city}</p>
                          </div>
                          <div className="flex items-center gap-3 flex-shrink-0">
                            <span className="text-sm font-semibold">
                              {Number(order.total_amount).toFixed(3)} TND
                            </span>
                            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border font-medium ${cfg.color}`}>
                              {cfg.icon} {cfg.label}
                            </span>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* ─── Mes produits récents ─── */}
          <div>
            <Card className="border-none shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-3">
                <CardTitle className="text-base">Mes produits</CardTitle>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/vendeur/produits" className="text-primary text-xs">
                    Gérer <ArrowUpRight className="w-3 h-3 ml-1 inline" />
                  </Link>
                </Button>
              </CardHeader>
              <CardContent>
                {recentProducts.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <Package className="w-10 h-10 mx-auto mb-2 opacity-30" />
                    <p className="text-sm mb-3">Aucun produit</p>
                    <Button size="sm" asChild>
                      <Link href="/vendeur/produits/ajouter">
                        <Plus className="w-4 h-4 mr-1" /> Ajouter
                      </Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {recentProducts.map((product: any) => (
                      <div key={product.id} className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                          <img
                            src={product.image_url || "/placeholder.svg"}
                            alt={product.name}
                            className="w-full h-full object-cover"
                            onError={(e) => { (e.target as HTMLImageElement).src = "/placeholder.svg" }}
                          />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium truncate">{product.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {Number(product.price || 0).toFixed(3)} TND
                          </p>
                        </div>
                        <Button variant="ghost" size="icon" className="w-7 h-7 flex-shrink-0" asChild>
                          <Link href={`/produits/${product.id}`}>
                            <Eye className="w-3.5 h-3.5" />
                          </Link>
                        </Button>
                      </div>
                    ))}
                    <Button variant="outline" size="sm" className="w-full mt-2" asChild>
                      <Link href="/vendeur/produits/ajouter">
                        <Plus className="w-4 h-4 mr-1" /> Nouveau produit
                      </Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* ─── Accès rapides mobile ─── */}
        <div className="md:hidden grid grid-cols-2 gap-3 pb-24">
          {[
            { href: "/vendeur/produits", icon: Package, label: "Mes produits", color: "text-blue-600 bg-blue-50" },
            { href: "/vendeur/commandes", icon: ShoppingBag, label: "Commandes", color: "text-purple-600 bg-purple-50" },
            { href: "/vendeur/produits/ajouter", icon: Plus, label: "Ajouter", color: "text-green-600 bg-green-50" },
            { href: "/vendeur/profil", icon: Settings, label: "Paramètres", color: "text-gray-600 bg-gray-100" },
          ].map(({ href, icon: Icon, label, color }) => (
            <Link key={href} href={href}
              className="flex flex-col items-center gap-2 p-4 rounded-xl bg-background border shadow-sm hover:shadow-md transition-shadow">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${color}`}>
                <Icon className="w-5 h-5" />
              </div>
              <span className="text-sm font-medium">{label}</span>
            </Link>
          ))}
        </div>

      </main>
    </div>
  )
}